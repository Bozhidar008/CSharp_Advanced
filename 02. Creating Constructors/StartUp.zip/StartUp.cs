﻿
using System;

namespace DefiningClasses
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            string name = "Gosho";
            int age = 20;

            Person person = new Person();
            Person person1 = new Person(age);
            Person person2 = new Person(name, age);
        }
    }
    
}


